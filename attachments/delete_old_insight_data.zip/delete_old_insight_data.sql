-- Change to the relevant 'DB NAME' (There are 3 places within the script)
-- SCript is set to keep 12 months of data. Change as appropriate in line "DECLARE @months_keep"

ALTER DATABASE [DB_NAME] SET RECOVERY SIMPLE;
GO

ALTER TABLE [dbo].[ResourceModelLog] DROP CONSTRAINT [ResourceModelLog_RFI_FK];
ALTER TABLE [dbo].[DeployedResourceLog] DROP CONSTRAINT [DeployedResourceLog_CPI_FK];
ALTER TABLE [dbo].[ResourceLog] DROP CONSTRAINT [ResourceLog_RMI_FK];
ALTER TABLE [dbo].[DeployedResourceLog] DROP CONSTRAINT [DeployedResourceLog_ATI_FK];
ALTER TABLE [dbo].[ResourceLog] DROP CONSTRAINT [ResourceLog_DRLI_FK];
ALTER TABLE [dbo].[ResourceAttributeValueLog] DROP CONSTRAINT [AttrValueLog_AI_FK];
ALTER TABLE [dbo].[ResourceMappingLog] DROP CONSTRAINT [ResourceMappingLog_PRMLI_FK];
ALTER TABLE [dbo].[ResourceLockLog] DROP CONSTRAINT [ResourceLockLog_PLI_FK];
ALTER TABLE [dbo].[ResourceLockLog] DROP CONSTRAINT [ResourceLockLog_DI_FK];
ALTER TABLE [dbo].[ResourceMappingLog] DROP CONSTRAINT [ResourceMappingLog_DI_FK];
ALTER TABLE [dbo].[ReservedResourceLog] DROP CONSTRAINT [ReservedResourceLog_DI_FK];
ALTER TABLE [dbo].[ReservationSummaryLog] DROP CONSTRAINT [ReservationSummaryLog_TI_FK];
ALTER TABLE [dbo].[ResourceLockLog] DROP CONSTRAINT [ResourceLockLog_RI_FK];
ALTER TABLE [dbo].[ResourceLockLog] DROP CONSTRAINT [ResourceLockLog_PRI_FK];
ALTER TABLE [dbo].[ResourceAttributeValueLog] DROP CONSTRAINT [AttrValueLog_RI_FK];
ALTER TABLE [dbo].[ResourceMappingLog] DROP CONSTRAINT [ResourceMappingLog_SRI_FK];
ALTER TABLE [dbo].[ResourceMappingLog] DROP CONSTRAINT [ResourceMappingLog_TRI_FK];
ALTER TABLE [dbo].[ResourceMappingLog] DROP CONSTRAINT [ResourceMappingLog_PSRI_FK];
ALTER TABLE [dbo].[ReservedResourceLog] DROP CONSTRAINT [ReservedResourceLog_RI_FK];
ALTER TABLE [dbo].[ReservedResourceLog] DROP CONSTRAINT [ReservedResourceLog_PRI_FK];
ALTER TABLE [dbo].[FixedLookupValue] DROP CONSTRAINT [FixedLookupValue_LI_FK];
ALTER TABLE [dbo].[QueryLookup] DROP CONSTRAINT [QueryLookup_LI_FK];
ALTER TABLE [dbo].[SchemaField] DROP CONSTRAINT [SchemaField_TI_FK];
ALTER TABLE [dbo].[SchemaField] DROP CONSTRAINT [SchemaField_LI_FK];
ALTER TABLE [dbo].[SchemaRelation] DROP CONSTRAINT [SchemaRelation_PFI_FK];
ALTER TABLE [dbo].[SchemaRelation] DROP CONSTRAINT [SchemaRelation_CFI_FK];
ALTER TABLE [dbo].[AggregatedFunctions] DROP CONSTRAINT [AggregatedFunctions_TI_FK];

    
IF OBJECT_ID('tempdb..#resource_to_delete_ids') IS NOT NULL 
BEGIN 
DROP TABLE #resource_to_delete_ids
END

DECLARE @months_keep INT = 12 -- change it however you want
DECLARE @max_id BIGINT,@max_date DATE

SELECT @max_date = DATEADD(MONTH , (-1 * @months_keep),GETDATE() ) 

SELECT @max_id = 140000001

SET NOCOUNT ON

DECLARE @results INT, @SUM INT

SELECT @results = 1 , @SUM = 0

WHILE (@results > 0) 
BEGIN
   DELETE TOP(10000) 
   FROM Measurement  WITH (TABLOCK)
   WHERE EndTime IS NOT NULL AND  EndTime < @max_date  
   
   SET @results = @@ROWCOUNT
   SET @SUM = @SUM + @results

   PRINT @SUM
   
END

SELECT @results = 1 , @SUM = 0

WHILE (@results > 0 ) 
BEGIN
   DELETE TOP(10000) 
   FROM JobExecutionHistory  WITH (TABLOCK)
   WHERE ActualStartTime IS NOT NULL AND  ActualStartTime < @max_date  
   
   SET @results = @@ROWCOUNT
   SET @SUM = @SUM + @results

   PRINT @SUM
   
END


SELECT @results = 1 , @SUM = 0,@SUM = 0

SELECT Id 
INTO #resource_to_delete_ids
FROM  ResourceLog rl
WHERE Created < @max_date

CREATE INDEX temp_resource_ix ON #resource_to_delete_ids(Id)

UPDATE ResourceLockLog  WITH (TABLOCK)
SET ParentLogId = NULL,ParentResourceId = NULL
WHERE (EndDate IS NOT NULL AND  EndDate < @max_date)  
OR ResourceId IN (SELECT Id FROM #resource_to_delete_ids)
OR ParentResourceId IN (SELECT Id FROM #resource_to_delete_ids)


SELECT @results = 1 , @SUM = 0

WHILE (@results > 0 ) 
BEGIN
   DELETE TOP(10000) 
   FROM ResourceLockLog  WITH (TABLOCK)
   WHERE (EndDate IS NOT NULL AND  EndDate < @max_date)
   OR ResourceId IN (SELECT Id FROM #resource_to_delete_ids)
   OR ParentResourceId IN (SELECT Id FROM #resource_to_delete_ids)
   
   SET @results = @@ROWCOUNT
   SET @SUM = @SUM + @results

   PRINT @SUM
   
END

UPDATE ResourceMappingLog  WITH (TABLOCK)
SET ParentLogId = NULL,ParentResourceId = NULL
WHERE (StartDate IS NOT NULL AND  StartDate < @max_date)
OR ResourceId IN (SELECT Id FROM #resource_to_delete_ids)
OR ParentResourceId IN (SELECT Id FROM #resource_to_delete_ids)

SELECT @results = 1 , @SUM = 0

WHILE (@results > 0) 
BEGIN
   DELETE TOP(10000) 
   FROM ResourceMappingLog  WITH (TABLOCK)
   WHERE StartDate IS NOT NULL AND  StartDate < @max_date  
     OR ResourceId IN (SELECT Id FROM #resource_to_delete_ids)
	 OR ParentResourceId IN (SELECT Id FROM #resource_to_delete_ids)
   
   SET @results = @@ROWCOUNT
   SET @SUM = @SUM + @results

   PRINT @SUM
   
END

SELECT @results = 1 , @SUM = 0

WHILE (@results > 0) 
BEGIN
   DELETE TOP(10000) 
   FROM ExecutionResult  WITH (TABLOCK)
   WHERE StartTime IS NOT NULL AND  StartTime < @max_date  
   
   SET @results = @@ROWCOUNT
   SET @SUM = @SUM + @results

   PRINT @SUM
   
END

SELECT @results = 1 , @SUM = 0

WHILE (@results > 0) 
BEGIN
   DELETE TOP(10000) 
   FROM ReservationSummaryLog  WITH (TABLOCK)
   WHERE StartDate IS NOT NULL AND  StartDate < @max_date  
   
   SET @results = @@ROWCOUNT
   SET @SUM = @SUM + @results

   PRINT @SUM
   
END

SELECT @results = 1 , @SUM = 0

WHILE (@results > 0) 
BEGIN
   DELETE TOP(10000) rl
   FROM ReservedResourceLog rl WITH (TABLOCK)
   WHERE (EndDate IS NOT NULL AND  EndDate < @max_date)
   OR rl.ResourceId IN(SELECT Id FROM #resource_to_delete_ids) 
   OR rl.ParentResourceId IN(SELECT Id FROM #resource_to_delete_ids) 
   
   SET @results = @@ROWCOUNT
   SET @SUM = @SUM + @results

   PRINT @SUM
   
END

SELECT @results = 1 , @SUM = 0

WHILE (@results > 0 ) 
BEGIN
   DELETE TOP(10000) ravl 
   FROM ResourceAttributeValueLog  ravl  WITH (TABLOCK)
   INNER JOIN #resource_to_delete_ids r ON r.Id = ravl.ResourceId
   
   SET @results = @@ROWCOUNT
   SET @SUM = @SUM + @results

   PRINT @SUM
   
END

SELECT @results = 1 , @SUM = 0

WHILE (@results > 0) -- and @SUM < 100000) 
BEGIN
   DELETE TOP(10000) rl
   FROM ResourceLog rl WITH (TABLOCK)
   INNER JOIN #resource_to_delete_ids r ON r.Id = rl.Id 
   
   SET @results = @@ROWCOUNT
   SET @SUM = @SUM + @results

   PRINT @SUM
   
END

SELECT @results = 1 , @SUM = 0

WHILE (@results > 0) -- AND @SUM < 10000)
BEGIN
   DELETE TOP(10000) 
   FROM ResourceUtilizationLog  WITH (TABLOCK)
   WHERE Id < 140000001
   
   SET @results = @@ROWCOUNT
   SET @SUM = @SUM + @results

   PRINT @SUM
 
END

ALTER TABLE [dbo].[ResourceModelLog] ADD CONSTRAINT [ResourceModelLog_RFI_FK] FOREIGN KEY ([ResourceFamilyId]) REFERENCES [dbo].[ResourceFamilyLog]([Id]);
ALTER TABLE [dbo].[DeployedResourceLog] ADD CONSTRAINT [DeployedResourceLog_CPI_FK] FOREIGN KEY ([CloudProviderId]) REFERENCES [dbo].[CloudProviderLog]([Id]);
ALTER TABLE [dbo].[ResourceLog] ADD CONSTRAINT [ResourceLog_RMI_FK] FOREIGN KEY ([ResourceModelId]) REFERENCES [dbo].[ResourceModelLog]([Id]);
ALTER TABLE [dbo].[DeployedResourceLog] ADD CONSTRAINT [DeployedResourceLog_ATI_FK] FOREIGN KEY ([AppTemplateId]) REFERENCES [dbo].[AppTemplateLog]([Id]);
ALTER TABLE [dbo].[ResourceLog] ADD CONSTRAINT [ResourceLog_DRLI_FK] FOREIGN KEY ([DeployedResourceLogId]) REFERENCES [dbo].[DeployedResourceLog]([Id]);
ALTER TABLE [dbo].[ResourceLockLog] ADD CONSTRAINT [ResourceLockLog_RI_FK] FOREIGN KEY ([ResourceId]) REFERENCES [dbo].[ResourceLog]([Id]);
ALTER TABLE [dbo].[ResourceLockLog] ADD CONSTRAINT [ResourceLockLog_PRI_FK] FOREIGN KEY ([ParentResourceId]) REFERENCES [dbo].[ResourceLog]([Id]);
ALTER TABLE [dbo].[ResourceAttributeValueLog] ADD CONSTRAINT [AttrValueLog_RI_FK] FOREIGN KEY ([ResourceId]) REFERENCES [dbo].[ResourceLog]([Id]);
ALTER TABLE [dbo].[ResourceMappingLog] ADD CONSTRAINT [ResourceMappingLog_SRI_FK] FOREIGN KEY ([ResourceId]) REFERENCES [dbo].[ResourceLog]([Id]);
ALTER TABLE [dbo].[ResourceMappingLog] ADD CONSTRAINT [ResourceMappingLog_TRI_FK] FOREIGN KEY ([TargetResourceId]) REFERENCES [dbo].[ResourceLog]([Id]);
ALTER TABLE [dbo].[ResourceMappingLog] ADD CONSTRAINT [ResourceMappingLog_PSRI_FK] FOREIGN KEY ([ParentResourceId]) REFERENCES [dbo].[ResourceLog]([Id]);
ALTER TABLE [dbo].[ReservedResourceLog] ADD CONSTRAINT [ReservedResourceLog_RI_FK] FOREIGN KEY ([ResourceId]) REFERENCES [dbo].[ResourceLog]([Id]);
ALTER TABLE [dbo].[ReservedResourceLog] ADD CONSTRAINT [ReservedResourceLog_PRI_FK] FOREIGN KEY ([ParentResourceId]) REFERENCES [dbo].[ResourceLog]([Id]);
ALTER TABLE [dbo].[ResourceLockLog] ADD CONSTRAINT [ResourceLockLog_PLI_FK] FOREIGN KEY ([ParentLogId]) REFERENCES [dbo].[ResourceLockLog]([Id]);
ALTER TABLE [dbo].[ResourceAttributeValueLog] ADD CONSTRAINT [AttrValueLog_AI_FK] FOREIGN KEY ([AttributeId]) REFERENCES [dbo].[ResourceAttributeLog]([Id]);
ALTER TABLE [dbo].[ResourceMappingLog] ADD CONSTRAINT [ResourceMappingLog_PRMLI_FK] FOREIGN KEY ([ParentLogId]) REFERENCES [dbo].[ResourceMappingLog]([Id]);
ALTER TABLE [dbo].[ResourceLockLog] ADD CONSTRAINT [ResourceLockLog_DI_FK] FOREIGN KEY ([DomainId]) REFERENCES [dbo].[TestShellDomainLog]([Id]);
ALTER TABLE [dbo].[ResourceMappingLog] ADD CONSTRAINT [ResourceMappingLog_DI_FK] FOREIGN KEY ([DomainId]) REFERENCES [dbo].[TestShellDomainLog]([Id]);
ALTER TABLE [dbo].[ReservedResourceLog] ADD CONSTRAINT [ReservedResourceLog_DI_FK] FOREIGN KEY ([DomainId]) REFERENCES [dbo].[TestShellDomainLog]([Id]);
ALTER TABLE [dbo].[ReservationSummaryLog] ADD CONSTRAINT [ReservationSummaryLog_TI_FK] FOREIGN KEY ([TopologyId]) REFERENCES [dbo].[TopologyLog]([Id]);
ALTER TABLE [dbo].[FixedLookupValue] ADD CONSTRAINT [FixedLookupValue_LI_FK] FOREIGN KEY ([LookupId]) REFERENCES [dbo].[Lookup]([Id]);
ALTER TABLE [dbo].[QueryLookup] ADD CONSTRAINT [QueryLookup_LI_FK] FOREIGN KEY ([LookupId]) REFERENCES [dbo].[Lookup]([Id]);
ALTER TABLE [dbo].[SchemaField] ADD CONSTRAINT [SchemaField_LI_FK] FOREIGN KEY ([LookupId]) REFERENCES [dbo].[Lookup]([Id]);
ALTER TABLE [dbo].[SchemaField] ADD CONSTRAINT [SchemaField_TI_FK] FOREIGN KEY ([TableId]) REFERENCES [dbo].[SchemaTable]([Id]);
ALTER TABLE [dbo].[AggregatedFunctions] ADD CONSTRAINT [AggregatedFunctions_TI_FK] FOREIGN KEY ([TableId]) REFERENCES [dbo].[SchemaTable]([Id]);
ALTER TABLE [dbo].[SchemaRelation] ADD CONSTRAINT [SchemaRelation_PFI_FK] FOREIGN KEY ([ParentFieldId]) REFERENCES [dbo].[SchemaField]([Id]);
ALTER TABLE [dbo].[SchemaRelation] ADD CONSTRAINT [SchemaRelation_CFI_FK] FOREIGN KEY ([ChildFieldId]) REFERENCES [dbo].[SchemaField]([Id]);

DBCC SHRINKDATABASE  ([DB_NAME], 10);
ALTER DATABASE [DB_NAME] SET RECOVERY FULL;


